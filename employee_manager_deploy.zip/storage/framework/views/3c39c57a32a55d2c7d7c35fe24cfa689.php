<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">

            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">إدارة حسابات الموظفين</h1>
                    <p class="text-sm text-gray-500 mt-1">عرض، إضافة وتحديث بيانات الموظفين والأقسام وحالة التفعيل</p>
                </div>
                <a href="<?php echo e(route('employees.create')); ?>" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm rounded-lg shadow-sm transition flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                    <span>إضافة موظف جديد</span>
                </a>
            </div>

            <!-- Search & Filters -->
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-4">
                <form method="GET" action="<?php echo e(route('employees.index')); ?>" class="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <div>
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="البحث باسم الموظف أو البريد..." class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                    </div>
                    <div>
                        <select name="department_id" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">جميع الأقسام</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($dept->id); ?>" <?php echo e(request('department_id') == $dept->id ? 'selected' : ''); ?>><?php echo e($dept->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <select name="status" class="w-full text-sm rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">جميع الحالات</option>
                            <option value="active" <?php echo e(request('status') === 'active' ? 'selected' : ''); ?>>فعّال فقط</option>
                            <option value="inactive" <?php echo e(request('status') === 'inactive' ? 'selected' : ''); ?>>معطّل فقط</option>
                        </select>
                    </div>
                    <div class="flex items-center gap-2">
                        <button type="submit" class="w-full py-2 bg-gray-800 hover:bg-gray-900 text-white text-sm font-medium rounded-lg transition">تصفية</button>
                        <a href="<?php echo e(route('employees.index')); ?>" class="py-2 px-3 border border-gray-300 text-gray-600 hover:bg-gray-50 text-sm font-medium rounded-lg transition">إعادة</a>
                    </div>
                </form>
            </div>

            <!-- Employees Table -->
            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <?php if($employees->isEmpty()): ?>
                    <div class="text-center py-12 text-gray-500 text-sm">لا يوجد موظفون يطابقون خيارات البحث.</div>
                <?php else: ?>
                    <table class="w-full text-right text-sm">
                        <thead class="bg-gray-50 text-gray-600 text-xs font-semibold uppercase">
                            <tr>
                                <th class="py-3.5 px-6">الموظف</th>
                                <th class="py-3.5 px-6">البريد الإلكتروني</th>
                                <th class="py-3.5 px-6">القسم</th>
                                <th class="py-3.5 px-6">الصلاحية</th>
                                <th class="py-3.5 px-6">الحالة</th>
                                <th class="py-3.5 px-6 text-center">الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50 transition">
                                    <td class="py-4 px-6 font-bold text-gray-900">
                                        <div class="flex items-center gap-3">
                                            <span class="w-8 h-8 rounded-full bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold text-xs">
                                                <?php echo e(mb_substr($employee->name, 0, 1)); ?>

                                            </span>
                                            <span><?php echo e($employee->name); ?></span>
                                        </div>
                                    </td>
                                    <td class="py-4 px-6 text-gray-600 font-mono text-xs dir-ltr text-right"><?php echo e($employee->email); ?></td>
                                    <td class="py-4 px-6 text-gray-700 font-medium"><?php echo e($employee->department?->name ?? 'غير محدد'); ?></td>
                                    <td class="py-4 px-6">
                                        <span class="px-2 py-0.5 rounded-full text-xs font-semibold <?php echo e($employee->isAdmin() ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-800'); ?>">
                                            <?php echo e($employee->isAdmin() ? 'مدير نظام' : 'موظف'); ?>

                                        </span>
                                    </td>
                                    <td class="py-4 px-6">
                                        <?php if($employee->is_active): ?>
                                            <span class="px-2.5 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">فعّال</span>
                                        <?php else: ?>
                                            <span class="px-2.5 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">معطّل</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-4 px-6 text-center">
                                        <a href="<?php echo e(route('employees.edit', $employee)); ?>" class="text-indigo-600 hover:text-indigo-900 font-semibold text-xs px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition">تعديل والحالة</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="p-4 border-t border-gray-100">
                        <?php echo e($employees->links()); ?>

                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/fayez/Projects/web/employee_manager/resources/views/employees/index.blade.php ENDPATH**/ ?>